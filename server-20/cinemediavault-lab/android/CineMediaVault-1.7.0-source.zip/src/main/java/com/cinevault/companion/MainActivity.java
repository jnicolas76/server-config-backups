package com.cinevault.companion;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.net.http.SslError;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.ViewCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.mediarouter.app.MediaRouteButton;
import androidx.mediarouter.media.RouteListingPreference;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaTrack;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.Session;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.NotificationOptions;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.images.WebImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes3.dex */
public class MainActivity extends Activity {
    private static final String DEFAULT_SERVER = "";
    private static final String KEY_OFFLINE_FOLDER_PROMPTED = "offline_folder_prompted";
    private static final String KEY_OFFLINE_TREE = "offline_tree_uri";
    private static final String KEY_SERVER = "server";
    private static final String MOVIE_DOWNLOAD_DIR = "CineVault/Movies";
    private static final String OFFLINE_INDEX_FILE = "offline_index.jsonl";
    private static final String PREFS = "cinevault";
    private static final int REQUEST_OFFLINE_FOLDER = 80;
    private static final String TV_DOWNLOAD_DIR = "CineVault/TV_Shows";
    private MediaRouteButton castButton;
    private CastContext castContext;
    private Button castLaunchButton;
    private SessionManagerListener<Session> castSessionListener;
    private CastSession currentCastSession;
    private View customVideoView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private View introOverlay;
    private Button menuButton;
    private WifiManager.MulticastLock multicastLock;
    private String pendingDownloadDisposition;
    private String pendingDownloadMetadata;
    private String pendingDownloadMimeType;
    private String pendingDownloadUrl;
    private String pendingDownloadUserAgent;
    private SharedPreferences prefs;
    private FrameLayout root;
    private SessionManager sessionManager;
    private WebView webView;
    private boolean sawLoginPage = false;
    private boolean introPlayedAfterLogin = false;
    private final Handler introHandler = new Handler(Looper.getMainLooper());
    private final Handler offlineHandler = new Handler(Looper.getMainLooper());
    private final Handler nativeStateHandler = new Handler(Looper.getMainLooper());
    private final Runnable nativeStatePoll = new Runnable() {
        @Override public void run() {
            pushNativeMusicState();
            nativeStateHandler.postDelayed(this, 1000L);
        }
    };
    private boolean offlineMode = false;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().addFlags(128);
        this.prefs = getSharedPreferences(PREFS, 0);
        acquireMulticastLock();
        buildUi();
        configureWebView();
        requestOfflineMediaPermission();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4104);
        }
        nativeStateHandler.post(nativeStatePoll);
        if (hasServerUrl()) {
            maybePromptOfflineFolderThenLoad();
        } else {
            showServerDialog(true);
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OFFLINE_FOLDER && resultCode == -1 && data != null && data.getData() != null) {
            Uri treeUri = data.getData();
            int flags = data.getFlags() & 3;
            try {
                getContentResolver().takePersistableUriPermission(treeUri, flags);
            } catch (Exception e) {
            }
            this.prefs.edit().putString(KEY_OFFLINE_TREE, treeUri.toString()).apply();
            Toast.makeText(this, "Offline save folder selected. CineVault/Movies and CineVault/TV_Shows will be created there.", 1).show();
            if (this.pendingDownloadUrl != null) {
                String url = this.pendingDownloadUrl;
                String metadata = this.pendingDownloadMetadata;
                String userAgent = this.pendingDownloadUserAgent;
                String disposition = this.pendingDownloadDisposition;
                String mimeType = this.pendingDownloadMimeType;
                clearPendingDownload();
                startCineVaultDownload(url, userAgent, disposition, mimeType, metadata);
                return;
            }
            if (hasServerUrl()) {
                loadHome();
            }
        }
    }

    private void buildUi() {
        this.root = new FrameLayout(this);
        this.root.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.webView = new WebView(this);
        this.webView.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.root.addView(this.webView, new FrameLayout.LayoutParams(-1, -1));
        this.menuButton = new Button(this);
        this.menuButton.setText(coloredCmV());
        this.menuButton.setAllCaps(false);
        this.menuButton.setTextSize(10.0f);
        this.menuButton.setTextColor(-1);
        this.menuButton.setAlpha(0.36f);
        this.menuButton.setBackgroundColor(Color.rgb(28, 28, 31));
        this.menuButton.setOnClickListener(new View.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda25
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m39lambda$buildUi$0$comcinevaultcompanionMainActivity(view);
            }
        });
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(56), dp(42));
        params.gravity = 85;
        params.setMargins(0, 0, dp(12), dp(12));
        this.root.addView(this.menuButton, params);
        this.castLaunchButton = new Button(this);
        this.castLaunchButton.setText("Cast");
        this.castLaunchButton.setAllCaps(false);
        this.castLaunchButton.setTextSize(10.0f);
        this.castLaunchButton.setTextColor(-1);
        this.castLaunchButton.setAlpha(0.4f);
        this.castLaunchButton.setBackgroundColor(Color.rgb(28, 28, 31));
        this.castLaunchButton.setOnClickListener(new View.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda26
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m40lambda$buildUi$1$comcinevaultcompanionMainActivity(view);
            }
        });
        FrameLayout.LayoutParams castParams = new FrameLayout.LayoutParams(dp(54), dp(46));
        castParams.gravity = 85;
        castParams.setMargins(0, 0, dp(76), dp(10));
        this.root.addView(this.castLaunchButton, castParams);
        setContentView(this.root);
        enterImmersiveMode();
    }

    /* JADX INFO: renamed from: lambda$buildUi$0$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m39lambda$buildUi$0$comcinevaultcompanionMainActivity(View v) {
        showMaintenanceMenu();
    }

    /* JADX INFO: renamed from: lambda$buildUi$1$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m40lambda$buildUi$1$comcinevaultcompanionMainActivity(View v) {
        openCastPicker();
    }

    private void configureCast() {
        try {
            if (this.castButton == null) {
                this.castButton = new MediaRouteButton(this);
                this.castButton.setVisibility(8);
                this.root.addView(this.castButton, new FrameLayout.LayoutParams(1, 1));
            }
            this.castContext = CastContext.getSharedInstance(this);
            CastButtonFactory.setUpMediaRouteButton(this, this.castButton);
            this.sessionManager = this.castContext.getSessionManager();
            this.currentCastSession = this.sessionManager.getCurrentCastSession();
            this.castSessionListener = new SessionManagerListener<Session>() { // from class: com.cinevault.companion.MainActivity.1
                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionStarted(Session session, String sessionId) {
                    MainActivity.this.currentCastSession = (CastSession) session;
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionResumed(Session session, boolean wasSuspended) {
                    MainActivity.this.currentCastSession = (CastSession) session;
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionEnded(Session session, int error) {
                    MainActivity.this.currentCastSession = null;
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionStarting(Session session) {
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionStartFailed(Session session, int error) {
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionEnding(Session session) {
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionResuming(Session session, String sessionId) {
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionResumeFailed(Session session, int error) {
                }

                @Override // com.google.android.gms.cast.framework.SessionManagerListener
                public void onSessionSuspended(Session session, int reason) {
                }
            };
            this.sessionManager.addSessionManagerListener(this.castSessionListener, Session.class);
        } catch (Throwable th) {
            Toast.makeText(this, "Cast SDK unavailable on this device.", 0).show();
        }
    }

    private boolean ensureCastReady() {
        if (this.sessionManager != null) {
            this.currentCastSession = this.sessionManager.getCurrentCastSession();
            return true;
        }
        configureCast();
        return this.sessionManager != null;
    }

    private void openCastPicker() {
        if (ensureCastReady() && this.castButton != null) {
            this.castButton.performClick();
        }
    }

    private void configureWebView() {
        WebSettings settings = this.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(-1);
        settings.setMixedContentMode(0);
        settings.setUserAgentString(settings.getUserAgentString() + " CineMediaVaultAndroid/1.4");
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(this.webView, true);
        this.webView.addJavascriptInterface(new CineVaultBridge(), "CineVaultAndroid");
        this.webView.addJavascriptInterface(new MusicBridge(), "CineVaultNativeMusic");
        this.webView.setWebViewClient(new WebViewClient() { // from class: com.cinevault.companion.MainActivity.2
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    if (!MainActivity.this.isCineVaultDownloadUrl(uri.toString())) {
                        return false;
                    }
                    MainActivity.this.capturePageMetadataAndDownload(uri.toString(), null, null, null);
                    return true;
                }
                if (MainActivity.PREFS.equals(uri.getScheme()) && "set-server".equals(uri.getHost())) {
                    MainActivity.this.showServerDialog(false);
                    return true;
                }
                if (MainActivity.PREFS.equals(uri.getScheme()) && "offline".equals(uri.getHost())) {
                    MainActivity.this.showOfflineLibrary("Offline library");
                    return true;
                }
                if (MainActivity.PREFS.equals(uri.getScheme()) && "try-server".equals(uri.getHost())) {
                    MainActivity.this.offlineMode = false;
                    MainActivity.this.loadHome();
                    return true;
                }
                if (MainActivity.PREFS.equals(uri.getScheme()) && "set-offline-folder".equals(uri.getHost())) {
                    MainActivity.this.chooseOfflineFolder();
                    return true;
                }
                if (MainActivity.PREFS.equals(uri.getScheme()) && "play-offline".equals(uri.getHost())) {
                    MainActivity.this.playOffline(uri);
                    return true;
                }
                if (MainActivity.PREFS.equals(uri.getScheme()) && "delete-offline".equals(uri.getHost())) {
                    MainActivity.this.deleteOffline(uri);
                    return true;
                }
                MainActivity.this.startActivity(new Intent("android.intent.action.VIEW", uri));
                return true;
            }

            @Override // android.webkit.WebViewClient
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (MainActivity.this.shouldPlayIntroForUrl(url)) {
                    MainActivity.this.showIntroOverlay();
                }
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                MainActivity.this.enterImmersiveMode();
                MainActivity.this.injectDownloadClickCatcher();
                if (MainActivity.this.shouldPlayIntroForUrl(url)) {
                    MainActivity.this.showIntroOverlay();
                }
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    MainActivity.this.showOfflineLibrary(error != null ? error.getDescription().toString() : "Connection failed");
                }
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                if (request != null && request.isForMainFrame() && errorResponse != null && errorResponse.getStatusCode() >= 400) {
                    MainActivity.this.showWebErrorPage("CineMediaVault returned HTTP " + errorResponse.getStatusCode(), errorResponse.getReasonPhrase());
                }
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                if (MainActivity.this.isConfiguredServerUrl(error != null ? error.getUrl() : null)) {
                    handler.proceed();
                } else {
                    handler.cancel();
                    MainActivity.this.showWebErrorPage("HTTPS certificate blocked", "The certificate is not trusted for this server. Use the saved CineMediaVault server URL or install a trusted certificate.");
                }
            }
        });
        this.webView.setWebChromeClient(new WebChromeClient() { // from class: com.cinevault.companion.MainActivity.3
            @Override // android.webkit.WebChromeClient
            public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
                if (MainActivity.this.customVideoView == null) {
                    MainActivity.this.customVideoView = view;
                    MainActivity.this.customViewCallback = callback;
                    MainActivity.this.menuButton.setVisibility(8);
                    MainActivity.this.castLaunchButton.setVisibility(8);
                    MainActivity.this.webView.setVisibility(8);
                    MainActivity.this.root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                    MainActivity.this.enterImmersiveMode();
                    return;
                }
                callback.onCustomViewHidden();
            }

            @Override // android.webkit.WebChromeClient
            public void onHideCustomView() {
                MainActivity.this.hideCustomVideoView();
            }
        });
        this.webView.setDownloadListener(downloadListener());
    }

    /* JADX INFO: Access modifiers changed from: private */
    class CineVaultBridge {
        private CineVaultBridge() {
        }

        @JavascriptInterface
        public void download(final String url, final String metadataJson) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$CineVaultBridge$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    CineVaultBridge.this.m69x76e1b47a(url, metadataJson);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$download$0$com-cinevault-companion-MainActivity$CineVaultBridge, reason: not valid java name */
        /* synthetic */ void m69x76e1b47a(String url, String metadataJson) {
            MainActivity.this.startCineVaultDownload(MainActivity.this.absolutize(url), null, null, null, metadataJson);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void injectDownloadClickCatcher() {
        this.webView.evaluateJavascript("(function(){if(window.__cmvDownloadHooked)return;window.__cmvDownloadHooked=true;function meta(){var title=(document.querySelector('h1,.title,.hero-title')||{}).innerText||document.title||'';var sub=(document.querySelector('.subtitle,.meta,.hero-meta')||{}).innerText||'';var img=document.querySelector('img[src*=poster],img.poster,.poster img,.hero-poster img,img');var bgEl=document.querySelector('.poster,.hero,.hero-bg,.detail-bg,[style*=background-image]');var bg=bgEl?getComputedStyle(bgEl).backgroundImage:'';var bm=bg&&bg.match(/url\\([\"']?([^\"')]+)[\"']?\\)/);var poster=(img&&img.src)||(bm&&bm[1])||'';var summary=(document.querySelector('.summary,.overview,.description,.synopsis,.plot,p')||{}).innerText||'';return JSON.stringify({title:title.trim(),subtitle:sub.trim(),poster:poster,summary:summary.trim(),page:location.href});}function bad(u){u=(u||'').toLowerCase();return u.indexOf('fix-match')>=0||u.indexOf('apply-match')>=0||u.indexOf('upload-art')>=0||u.indexOf('poster')>=0||u.indexOf('artwork')>=0||u.indexOf('metadata')>=0||u.indexOf('admin')>=0;}function findUrl(el){var cur=el;for(var i=0;cur&&i<4;i++,cur=cur.parentElement){var href=cur.href||cur.getAttribute('href')||cur.getAttribute('data-href')||cur.getAttribute('data-url')||cur.getAttribute('formaction')||'';if(href&&!bad(href))return href;var oc=cur.getAttribute('onclick')||'';var m=oc.match(/['\\\"]([^'\\\"]*\\/download[^'\\\"]*)['\\\"]/);if(m&&!bad(m[1]))return m[1];}var nearby=el.closest('a[href*=download],button[data-url*=download]');var found=nearby?(nearby.href||nearby.getAttribute('data-url')||nearby.getAttribute('href')||''):'';return bad(found)?'':found;}document.addEventListener('click',function(e){var el=e.target.closest('a,button,[role=button]');if(!el)return;var text=(el.innerText||el.textContent||el.getAttribute('aria-label')||'').toLowerCase();var url=findUrl(el);var isDl=(url&&url.toLowerCase().indexOf('/download')>=0);if(!isDl)return;if(!url)return;try{url=new URL(url,location.href).toString();}catch(_){ }e.preventDefault();e.stopPropagation();CineVaultAndroid.download(url,meta());return false;},true);})();", null);
    }

    private DownloadListener downloadListener() {
        return new DownloadListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda20
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                MainActivity.this.m44lambda$downloadListener$2$comcinevaultcompanionMainActivity(str, str2, str3, str4, j);
            }
        };
    }

    /* JADX INFO: renamed from: lambda$downloadListener$2$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m44lambda$downloadListener$2$comcinevaultcompanionMainActivity(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            Toast.makeText(this, "Storage permission may be required for downloads.", 1).show();
        }
        capturePageMetadataAndDownload(url, userAgent, contentDisposition, mimeType);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void capturePageMetadataAndDownload(final String url, final String userAgent, final String contentDisposition, final String mimeType) {
        this.webView.evaluateJavascript("(function(){var title=(document.querySelector('h1,.title,.hero-title')||{}).innerText||document.title||'';var sub=(document.querySelector('.subtitle,.meta,.hero-meta')||{}).innerText||'';var img=document.querySelector('img[src*=poster],img.poster,.poster img,.hero-poster img,img');var bgEl=document.querySelector('.poster,.hero,.hero-bg,.detail-bg,[style*=background-image]');var bg=bgEl?getComputedStyle(bgEl).backgroundImage:'';var bm=bg&&bg.match(/url\\([\"']?([^\"')]+)[\"']?\\)/);var poster=(img&&img.src)||(bm&&bm[1])||'';var summary=(document.querySelector('.summary,.overview,.description,.synopsis,.plot,p')||{}).innerText||'';var page=location.href;return JSON.stringify({title:title.trim(),subtitle:sub.trim(),poster:poster,summary:summary.trim(),page:page});})()", new ValueCallback() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda8
            @Override // android.webkit.ValueCallback
            public final void onReceiveValue(Object obj) {
                MainActivity.this.m41xd3a99cea(url, userAgent, contentDisposition, mimeType, (String) obj);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$capturePageMetadataAndDownload$3$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m41xd3a99cea(String url, String userAgent, String contentDisposition, String mimeType, String value) {
        startCineVaultDownload(url, userAgent, contentDisposition, mimeType, stripJsString(value));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isCineVaultDownloadUrl(String url) {
        if (url == null) {
            return false;
        }
        String lower = url.toLowerCase(Locale.US);
        if (lower.contains("fix-match") || lower.contains("apply-match") || lower.contains("upload-art") || lower.contains("poster") || lower.contains("artwork") || lower.contains("metadata") || lower.contains("/admin")) {
            return false;
        }
        return lower.contains("/download/") || lower.contains("/download?");
    }

    private String cineVaultFilename(String url, String contentDisposition, String mimeType, String metadataJson, String kind) {
        String title;
        String subtitle;
        String base;
        String guessed = URLUtil.guessFileName(url, contentDisposition, mimeType);
        String lower = guessed == null ? "" : guessed.toLowerCase(Locale.US);
        if (!guessedLooksGeneric(lower)) {
            return normalizeDownloadedName(sanitizeFilename(guessed), kind, url, mimeType, contentDisposition);
        }
        String title2 = "";
        try {
            JSONObject metadata = new JSONObject((metadataJson == null || !metadataJson.trim().startsWith("{")) ? "{}" : metadataJson);
            title2 = metadata.optString("title", "");
            String subtitle2 = metadata.optString(MediaTrack.ROLE_SUBTITLE, "");
            title = title2;
            subtitle = subtitle2;
        } catch (Exception e) {
            title = title2;
            subtitle = "";
        }
        String base2 = (title + " " + subtitle).replaceAll("\\s+", " ").trim();
        if (base2.isEmpty()) {
            base = "tv".equals(kind) ? "CineMediaVault TV Episode" : "CineMediaVault Movie";
        } else {
            base = base2;
        }
        String ext = extensionForMimeOrUrl(mimeType, url, contentDisposition);
        return normalizeDownloadedName(sanitizeFilename(base) + ext, kind, url, mimeType, contentDisposition);
    }

    private String normalizeDownloadedName(String filename, String kind, String url, String mimeType, String contentDisposition) {
        String name;
        String name2 = sanitizeFilename(filename);
        String lower = name2.toLowerCase(Locale.US);
        boolean seasonZip = "tv".equals(kind) && extensionForMimeOrUrl(mimeType, url, contentDisposition).equals(".zip");
        if (seasonZip || lower.contains(".zip.")) {
            int marker = lower.indexOf(".zip");
            if (marker >= 0) {
                name = name2.substring(0, marker);
            } else {
                name = stripKnownExtension(name2);
            }
            return sanitizeFilename(name) + ".zip";
        }
        return name2;
    }

    private boolean guessedLooksGeneric(String lower) {
        return lower.isEmpty() || lower.endsWith(".bin") || lower.matches(".*[/\\\\]?[0-9]+(\\.[a-z0-9]{2,5})?$");
    }

    private String extensionForMimeOrUrl(String mimeType, String url, String contentDisposition) {
        String lowerUrl = url == null ? "" : url.toLowerCase(Locale.US);
        String lowerDisposition = contentDisposition == null ? "" : contentDisposition.toLowerCase(Locale.US);
        if (lowerDisposition.contains(".zip") || lowerUrl.contains(".zip") || lowerUrl.contains("/download/season")) {
            return ".zip";
        }
        String[] strArr = {".mp4", ".m4v", ".mkv", ".avi", ".webm", ".mov", ".zip"};
        for (int i = 0; i < 7; i++) {
            String ext = strArr[i];
            if (lowerDisposition.contains(ext) || lowerUrl.contains(ext)) {
                return ext;
            }
        }
        String lowerMime = mimeType != null ? mimeType.toLowerCase(Locale.US) : "";
        if (lowerMime.contains("zip")) {
            return ".zip";
        }
        return lowerMime.contains("matroska") ? ".mkv" : lowerMime.contains("avi") ? ".avi" : lowerMime.contains("webm") ? ".webm" : ".mp4";
    }

    private String sanitizeFilename(String value) {
        String cleaned = value == null ? "" : value.replaceAll("[\\\\/:*?\"<>|]", " ").replaceAll("\\s+", " ").trim();
        if (cleaned.length() > 140) {
            cleaned = cleaned.substring(0, 140).trim();
        }
        return cleaned.isEmpty() ? "CineMediaVault Video" : cleaned;
    }

    private String stripKnownExtension(String filename) {
        String lower = filename == null ? "" : filename.toLowerCase(Locale.US);
        String[] strArr = {".mp4", ".m4v", ".mkv", ".avi", ".webm", ".mov", ".zip", ".bin"};
        for (int i = 0; i < 8; i++) {
            String ext = strArr[i];
            if (lower.endsWith(ext)) {
                return filename.substring(0, filename.length() - ext.length());
            }
        }
        return filename;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startCineVaultDownload(String url, String userAgent, String contentDisposition, String mimeType, String metadataJson) {
        try {
            String kind = classifyDownload(url, metadataJson);
            String filename = cineVaultFilename(url, contentDisposition, mimeType, metadataJson, kind);
            String str = "tv".equals(kind) ? TV_DOWNLOAD_DIR : MOVIE_DOWNLOAD_DIR;
            Uri customTree = selectedOfflineTree();
            if (customTree == null) {
                this.pendingDownloadUrl = url;
                this.pendingDownloadMetadata = metadataJson;
                this.pendingDownloadUserAgent = userAgent;
                this.pendingDownloadDisposition = contentDisposition;
                this.pendingDownloadMimeType = mimeType;
                Toast.makeText(this, "Choose where CineMediaVault should save offline videos.", 1).show();
                chooseOfflineFolder();
                return;
            }
            if (selectedTreeConflictsWithKind(customTree, kind)) {
                this.pendingDownloadUrl = url;
                this.pendingDownloadMetadata = metadataJson;
                this.pendingDownloadUserAgent = userAgent;
                this.pendingDownloadDisposition = contentDisposition;
                this.pendingDownloadMimeType = mimeType;
                Toast.makeText(this, "Choose the parent CineVault or Download folder so Movies and TV_Shows can be saved side by side.", 1).show();
                chooseOfflineFolder();
                return;
            }
            startManualTreeDownload(customTree, kind, filename, url, metadataJson);
        } catch (Exception ex) {
            Toast.makeText(this, "Download failed to start: " + ex.getMessage(), 1).show();
        }
    }

    private void clearPendingDownload() {
        this.pendingDownloadUrl = null;
        this.pendingDownloadMetadata = null;
        this.pendingDownloadUserAgent = null;
        this.pendingDownloadDisposition = null;
        this.pendingDownloadMimeType = null;
    }

    private Uri selectedOfflineTree() {
        String value = this.prefs.getString(KEY_OFFLINE_TREE, "");
        if (value == null || value.trim().isEmpty()) {
            return null;
        }
        return Uri.parse(value);
    }

    private boolean selectedTreeConflictsWithKind(Uri treeUri, String kind) {
        try {
            DocumentFile rootDoc = DocumentFile.fromTreeUri(this, treeUri);
            String selectedName = (rootDoc == null || rootDoc.getName() == null) ? "" : rootDoc.getName();
            if (!"tv".equals(kind) || !selectedName.equalsIgnoreCase("Movies")) {
                if (!"movie".equals(kind)) {
                    return false;
                }
                if (!selectedName.equalsIgnoreCase("TV_Shows")) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void startManualTreeDownload(final Uri treeUri, final String kind, final String filename, final String url, final String metadataJson) {
        Toast.makeText(this, "Downloading offline: " + filename, 0).show();
        final String downloadUserAgent = this.webView.getSettings().getUserAgentString();
        final String downloadCookie = CookieManager.getInstance().getCookie(url);
        new Thread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m63x3e019e1f(filename, treeUri, kind, url, downloadCookie, downloadUserAgent, metadataJson);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$startManualTreeDownload$10$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m63x3e019e1f(String filename, Uri treeUri, String kind, String url, String downloadCookie, String downloadUserAgent, String metadataJson) {
        String outName;
        String outName2 = filename;
        try {
            DocumentFile rootDoc = DocumentFile.fromTreeUri(this, treeUri);
            if (rootDoc == null || !rootDoc.canWrite()) {
                throw new Exception("Selected folder is not writable.");
            }
            DocumentFile mediaDir = resolveOfflineMediaDir(rootDoc, kind);
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            if ((connection instanceof HttpsURLConnection) && isConfiguredServerUrl(url)) {
                HttpsURLConnection https = (HttpsURLConnection) connection;
                https.setSSLSocketFactory(trustAllSslContext().getSocketFactory());
                https.setHostnameVerifier(new HostnameVerifier() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda12
                    @Override // javax.net.ssl.HostnameVerifier
                    public final boolean verify(String str, SSLSession sSLSession) {
                        return MainActivity.lambda$startManualTreeDownload$4(str, sSLSession);
                    }
                });
            }
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            if (downloadCookie != null) {
                connection.setRequestProperty("Cookie", downloadCookie);
            }
            if (downloadUserAgent != null) {
                connection.setRequestProperty("User-Agent", downloadUserAgent);
            }
            connection.connect();
            int code = connection.getResponseCode();
            if (code >= 400) {
                throw new Exception("HTTP " + code);
            }
            long expectedBytes = connection.getContentLengthLong();
            String headerName = URLUtil.guessFileName(url, connection.getHeaderField("Content-Disposition"), connection.getContentType());
            if (headerName == null || guessedLooksGeneric(headerName.toLowerCase(Locale.US))) {
                String refinedExt = extensionForMimeOrUrl(connection.getContentType(), url, connection.getHeaderField("Content-Disposition"));
                if (outName2.toLowerCase(Locale.US).endsWith(".zip")) {
                    refinedExt = ".zip";
                }
                if (!outName2.toLowerCase(Locale.US).endsWith(refinedExt)) {
                    outName2 = stripKnownExtension(outName2) + refinedExt;
                }
            } else {
                outName2 = sanitizeFilename(headerName);
            }
            String refinedExt2 = connection.getContentType();
            if (extensionForMimeOrUrl(refinedExt2, url, connection.getHeaderField("Content-Disposition")).equals(".zip") && !outName2.toLowerCase(Locale.US).endsWith(".zip")) {
                String outName3 = stripKnownExtension(outName2);
                if (!outName3.toLowerCase(Locale.US).endsWith(".zip")) {
                    outName = outName3 + ".zip";
                } else {
                    outName = outName3;
                }
            } else {
                outName = outName2;
            }
            final String outName4 = normalizeDownloadedName(outName, kind, url, connection.getContentType(), connection.getHeaderField("Content-Disposition"));
            DocumentFile existing = mediaDir.findFile(outName4);
            if (existing != null) {
                existing.delete();
            }
            String mime = guessMime(outName4);
            DocumentFile outFile = mediaDir.createFile(mime, outName4);
            if (outFile == null) {
                throw new Exception("Could not create output file.");
            }
            InputStream input = connection.getInputStream();
            OutputStream output = getContentResolver().openOutputStream(outFile.getUri(), "w");
            if (output == null) {
                throw new Exception("Could not open output stream.");
            }
            byte[] buffer = new byte[262144];
            int lastProgress = -10;
            long total = 0;
            while (true) {
                int read = input.read(buffer);
                String mime2 = mime;
                if (read == -1) {
                    break;
                }
                output.write(buffer, 0, read);
                total += (long) read;
                if (expectedBytes > 0) {
                    final int progress = (int) Math.min(100L, (total * 100) / expectedBytes);
                    if (progress >= lastProgress + 10) {
                        runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda13
                            @Override // java.lang.Runnable
                            public final void run() {
                                MainActivity.this.m64xe190cccf(progress, outName4);
                            }
                        });
                        lastProgress = progress;
                    }
                    mime = mime2;
                } else {
                    mime = mime2;
                }
            }
            output.flush();
            output.close();
            input.close();
            connection.disconnect();
            rememberOfflineDownload(kind, "custom", outName4, url, metadataJson, outFile.getUri().toString());
            final long mb = Math.max(1L, total / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED);
            if (!"tv".equals(kind) || !outName4.toLowerCase(Locale.US).endsWith(".zip")) {
                runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda16
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.this.m67x588a2ac(outName4, mb);
                    }
                });
            } else {
                runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda14
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.this.m65x42e3696e(outName4);
                    }
                });
                final int extracted = unzipSeasonBundle(outFile, mediaDir, outName4, url, metadataJson);
                removeOfflineEntry(outFile.getUri().toString());
                outFile.delete();
                runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda15
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.this.m66xa436060d(extracted);
                    }
                });
            }
        } catch (Exception ex) {
            final String message = ex.getClass().getSimpleName() + ": " + (ex.getMessage() != null ? ex.getMessage() : "unknown error");
            runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m68x66db3f4b(message);
                }
            });
        }
    }

    static /* synthetic */ boolean lambda$startManualTreeDownload$4(String hostname, SSLSession session) {
        return true;
    }

    /* JADX INFO: renamed from: lambda$startManualTreeDownload$5$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m64xe190cccf(int progressValue, String progressName) {
        Toast.makeText(this, "Downloading " + progressValue + "%: " + progressName, 0).show();
    }

    /* JADX INFO: renamed from: lambda$startManualTreeDownload$6$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m65x42e3696e(String toastName) {
        Toast.makeText(this, "Download complete. Unzipping season: " + toastName, 1).show();
    }

    /* JADX INFO: renamed from: lambda$startManualTreeDownload$7$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m66xa436060d(int extracted) {
        Toast.makeText(this, "Season ready offline: " + extracted + " video file(s) extracted.", 1).show();
    }

    /* JADX INFO: renamed from: lambda$startManualTreeDownload$8$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m67x588a2ac(String toastName, long mb) {
        Toast.makeText(this, "Offline saved: " + toastName + " (" + mb + " MB)", 1).show();
    }

    /* JADX INFO: renamed from: lambda$startManualTreeDownload$9$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m68x66db3f4b(String message) {
        Toast.makeText(this, "Offline download failed: " + message, 1).show();
    }

    private int unzipSeasonBundle(DocumentFile zipFile, DocumentFile tvRoot, String zipName, String sourceUrl, String metadataJson) throws Exception {
        JSONObject seasonManifest = null;
        JSONObject seasonManifest2;
        String seasonName = sanitizeFilename(stripKnownExtension(zipName));
        DocumentFile seasonDir = tvRoot.findFile(seasonName);
        DocumentFile seasonDir2 = (seasonDir == null || !seasonDir.isDirectory()) ? tvRoot.createDirectory(seasonName) : seasonDir;
        if (seasonDir2 == null) {
            throw new Exception("Could not create season folder.");
        }
        InputStream rawInput = getContentResolver().openInputStream(zipFile.getUri());
        if (rawInput == null) {
            throw new Exception("Could not reopen downloaded ZIP.");
        }
        ZipInputStream zipInput = new ZipInputStream(rawInput);
        byte[] buffer = new byte[131072];
        int extractedVideos = 0;
        JSONObject seasonManifest3 = null;
        while (true) {
            ZipEntry entry = zipInput.getNextEntry();
            if (entry == null) {
                break;
            }
            String entryName = entry.getName() == null ? "" : entry.getName();
            if (entryName.trim().isEmpty()) {
                seasonManifest = seasonManifest3;
            } else if (entryName.contains("__MACOSX")) {
                seasonManifest = seasonManifest3;
            } else {
                if (entry.isDirectory()) {
                    ensureZipPath(seasonDir2, entryName, true);
                    zipInput.closeEntry();
                    seasonManifest = seasonManifest3;
                } else {
                    DocumentFile parent = ensureZipPath(seasonDir2, entryName, false);
                    String leafName = sanitizeFilename(zipLeafName(entryName));
                    if (leafName.isEmpty()) {
                        zipInput.closeEntry();
                        seasonManifest = seasonManifest3;
                    } else {
                        int i = -1;
                        if ("cinemediavault-season.json".equalsIgnoreCase(leafName)) {
                            StringBuilder manifestText = new StringBuilder();
                            while (true) {
                                int read = zipInput.read(buffer);
                                if (read == i) {
                                    break;
                                }
                                manifestText.append(new String(buffer, 0, read, "UTF-8"));
                                entryName = entryName;
                                i = -1;
                            }
                            try {
                                JSONObject seasonManifest4 = new JSONObject(manifestText.toString());
                                seasonManifest3 = seasonManifest4;
                            } catch (Exception e) {
                                seasonManifest3 = null;
                            }
                            zipInput.closeEntry();
                        } else {
                            DocumentFile existing = parent.findFile(leafName);
                            if (existing != null) {
                                existing.delete();
                            }
                            DocumentFile outFile = parent.createFile(guessMime(leafName), leafName);
                            if (outFile == null) {
                                zipInput.closeEntry();
                                seasonManifest = seasonManifest3;
                            } else {
                                OutputStream output = getContentResolver().openOutputStream(outFile.getUri(), "w");
                                if (output == null) {
                                    zipInput.closeEntry();
                                    seasonManifest = seasonManifest3;
                                } else {
                                    while (true) {
                                        int read2 = zipInput.read(buffer);
                                        if (read2 == -1) {
                                            break;
                                        }
                                        output.write(buffer, 0, read2);
                                    }
                                    output.flush();
                                    output.close();
                                    if (isVideoFile(leafName)) {
                                        seasonManifest2 = seasonManifest3;
                                        rememberOfflineDownload("tv", "custom", leafName, sourceUrl, metadataForExtractedEpisode(metadataJson, seasonManifest3, leafName), outFile.getUri().toString());
                                        extractedVideos++;
                                    } else {
                                        seasonManifest2 = seasonManifest3;
                                    }
                                    zipInput.closeEntry();
                                    seasonManifest3 = seasonManifest2;
                                }
                            }
                        }
                    }
                }
                seasonManifest3 = seasonManifest;
            }
            zipInput.closeEntry();
            seasonManifest3 = seasonManifest;
        }
        zipInput.close();
        if (extractedVideos == 0) {
            throw new Exception("Downloaded file was not a valid season ZIP.");
        }
        return extractedVideos;
    }

    private DocumentFile ensureZipPath(DocumentFile rootDir, String entryName, boolean includeLeaf) throws Exception {
        String normalized = entryName.replace('\\', '/');
        String[] parts = normalized.split("/");
        int count = parts.length;
        if (!includeLeaf) {
            count = Math.max(0, count - 1);
        }
        DocumentFile current = rootDir;
        for (int i = 0; i < count; i++) {
            String part = sanitizeFilename(parts[i]);
            if (!part.isEmpty() && !".".equals(part) && !"..".equals(part)) {
                current = ensureDocumentDir(current, part);
            }
        }
        return current;
    }

    private String zipLeafName(String entryName) {
        String normalized = entryName.replace('\\', '/');
        int slash = normalized.lastIndexOf(47);
        return slash >= 0 ? normalized.substring(slash + 1) : normalized;
    }

    private String metadataWithEpisodeTitle(String metadataJson, String filename) {
        try {
            JSONObject metadata = new JSONObject((metadataJson == null || !metadataJson.trim().startsWith("{")) ? "{}" : metadataJson);
            metadata.put("title", niceTitleFromFile(filename));
            metadata.put(MediaTrack.ROLE_SUBTITLE, "TV Show");
            return metadata.toString();
        } catch (Exception e) {
            return "{\"title\":\"" + niceTitleFromFile(filename).replace("\"", "") + "\",\"subtitle\":\"TV Show\"}";
        }
    }

    private String metadataForExtractedEpisode(String metadataJson, JSONObject seasonManifest, String filename) {
        if (seasonManifest != null) {
            try {
                JSONObject episodes = seasonManifest.optJSONObject("episodes");
                JSONObject episode = episodes != null ? episodes.optJSONObject(filename) : null;
                if (episode != null) {
                    JSONObject metadata = new JSONObject((metadataJson == null || !metadataJson.trim().startsWith("{")) ? "{}" : metadataJson);
                    String show = episode.optString("show", seasonManifest.optString("show", ""));
                    String ep = episode.optString("episode", "");
                    String title = episode.optString("title", niceTitleFromFile(filename));
                    String fullTitle = (show + " - " + ep + " - " + title).replaceAll("\\s+", " ").replace(" -  - ", " - ").trim();
                    metadata.put("title", fullTitle);
                    metadata.put(MediaTrack.ROLE_SUBTITLE, "TV Show");
                    metadata.put("summary", episode.optString("summary", seasonManifest.optString("summary", metadata.optString("summary", ""))));
                    String still = episode.optString("still", "");
                    String poster = episode.optString("poster", seasonManifest.optString("poster", metadata.optString("poster", "")));
                    metadata.put("poster", !still.isEmpty() ? still : poster);
                    return metadata.toString();
                }
            } catch (Exception e) {
            }
        }
        return metadataWithEpisodeTitle(metadataJson, filename);
    }

    private DocumentFile ensureDocumentDir(DocumentFile parent, String name) throws Exception {
        DocumentFile child = parent.findFile(name);
        if (child != null && child.isDirectory()) {
            return child;
        }
        DocumentFile child2 = parent.createDirectory(name);
        if (child2 == null) {
            throw new Exception("Could not create folder: " + name);
        }
        return child2;
    }

    private DocumentFile resolveOfflineMediaDir(DocumentFile selectedRoot, String kind) throws Exception {
        DocumentFile existingTarget;
        String target = "tv".equals(kind) ? "TV_Shows" : "Movies";
        String selectedName = selectedRoot.getName() != null ? selectedRoot.getName() : "";
        if (selectedName.equalsIgnoreCase(target)) {
            return selectedRoot;
        }
        if (selectedName.equalsIgnoreCase("CineVault")) {
            return ensureDocumentDir(selectedRoot, target);
        }
        DocumentFile existingCine = selectedRoot.findFile("CineVault");
        if (existingCine != null && existingCine.isDirectory() && (existingTarget = existingCine.findFile(target)) != null && existingTarget.isDirectory()) {
            return existingTarget;
        }
        DocumentFile existingTarget2 = selectedRoot.findFile(target);
        if (existingTarget2 != null && existingTarget2.isDirectory()) {
            return existingTarget2;
        }
        if (selectedName.equalsIgnoreCase("Movies") || selectedName.equalsIgnoreCase("TV_Shows")) {
            runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m49xe0ed526a();
                }
            });
            return selectedRoot;
        }
        DocumentFile cineDir = ensureDocumentDir(selectedRoot, "CineVault");
        return ensureDocumentDir(cineDir, target);
    }

    /* JADX INFO: renamed from: lambda$resolveOfflineMediaDir$11$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m49xe0ed526a() {
        Toast.makeText(this, "Choose Change Offline Save Folder and select the parent CineVault or Download folder for mixed Movies and TV saves.", 1).show();
    }

    private void showMaintenanceMenu() {
        String saveLabel = selectedOfflineTree() == null ? "Set Offline Save Folder" : "Change Offline Save Folder";
        String[] options = {"Cast Current Video", "Offline Library", saveLabel, "Use Default Downloads Folder", "Reload", "Home", "Back", "Set Server", "Open in Browser", "Clear Web Cache"};
        new AlertDialog.Builder(this).setTitle("CineMediaVault").setItems(options, new DialogInterface.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda18
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m60x31303b04(dialogInterface, i);
            }
        }).show();
    }

    /* JADX INFO: renamed from: lambda$showMaintenanceMenu$12$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m60x31303b04(DialogInterface dialog, int which) {
        if (which == 0) {
            castCurrentVideo();
        }
        if (which == 1) {
            showOfflineLibrary("Offline library");
        }
        if (which == 2) {
            chooseOfflineFolder();
        }
        if (which == 3) {
            this.prefs.edit().remove(KEY_OFFLINE_TREE).apply();
            Toast.makeText(this, "Offline saves reset to Downloads/CineVault.", 1).show();
        }
        if (which == 4) {
            this.webView.reload();
        }
        if (which == 5) {
            loadHome();
        }
        if (which == 6) {
            goBack();
        }
        if (which == 7) {
            showServerDialog();
        }
        if (which == 8) {
            openExternal();
        }
        if (which == 9) {
            this.webView.clearCache(true);
            Toast.makeText(this, "Web cache cleared.", 0).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void chooseOfflineFolder() {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.addFlags(195);
        startActivityForResult(intent, REQUEST_OFFLINE_FOLDER);
    }

    private void castCurrentVideo() {
        if (!ensureCastReady()) {
            return;
        }
        if (this.currentCastSession == null || !this.currentCastSession.isConnected()) {
            Toast.makeText(this, "Choose a Cast device first.", 1).show();
            openCastPicker();
        } else {
            this.webView.evaluateJavascript("(function(){var v=document.querySelector('video')||document.querySelector('audio');var src=v&&(v.currentSrc||v.src||(v.querySelector('source')&&v.querySelector('source').src));var title=(document.querySelector('#npTitle,h1,.title,.hero-title')||{}).innerText||document.title||'CineMediaVault';var poster=(v&&v.poster)||((document.querySelector('#npArt,img[src*=poster],img.poster,.poster img')||{}).src)||'';var type=(v&&(v.type||(v.querySelector('source')&&v.querySelector('source').type)))||'';var duration=(v&&isFinite(v.duration))?v.duration:0;JSON.stringify({src:src||'',title:title.trim(),poster:poster,type:type,duration:duration,kind:(v&&v.tagName==='AUDIO')?'audio':'video'});})()", new ValueCallback() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda6
                @Override // android.webkit.ValueCallback
                public final void onReceiveValue(Object obj) {
                    MainActivity.this.m42lambda$castCurrentVideo$13$comcinevaultcompanionMainActivity((String) obj);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$castCurrentVideo$13$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m42lambda$castCurrentVideo$13$comcinevaultcompanionMainActivity(String value) {
        try {
            String json = stripJsString(value);
            JSONObject media = new JSONObject(json);
            String src = absolutize(media.optString("src", ""));
            if (src.isEmpty()) {
                Toast.makeText(this, "Open or start media before casting.", 1).show();
            } else {
                loadCastMedia(src, media.optString("title", "CineMediaVault"), absolutize(media.optString("poster", "")), media.optString("type", ""), media.optDouble("duration", 0.0d), "audio".equals(media.optString("kind", "")));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not read the current media for Cast.", 1).show();
        }
    }

    private void loadCastMedia(String src, String title, String poster, String type, double durationSeconds, boolean music) {
        RemoteMediaClient client = this.currentCastSession.getRemoteMediaClient();
        if (client == null) {
            Toast.makeText(this, "Cast media client is not ready.", 1).show();
            return;
        }
        MediaMetadata metadata = new MediaMetadata(music ? MediaMetadata.MEDIA_TYPE_MUSIC_TRACK : MediaMetadata.MEDIA_TYPE_MOVIE);
        metadata.putString(MediaMetadata.KEY_TITLE, title);
        metadata.putString(MediaMetadata.KEY_SUBTITLE, "CineMediaVault");
        if (!poster.isEmpty()) {
            metadata.addImage(new WebImage(Uri.parse(poster)));
        }
        String contentType = (type == null || type.isEmpty()) ? guessMime(src, music) : type;
        MediaInfo.Builder infoBuilder = new MediaInfo.Builder(src).setContentType(contentType).setStreamType(1).setMetadata(metadata);
        if (durationSeconds > 0.0d) {
            infoBuilder.setStreamDuration((long) (1000.0d * durationSeconds));
        }
        MediaLoadRequestData request = new MediaLoadRequestData.Builder().setMediaInfo(infoBuilder.build()).setAutoplay(true).setCurrentTime(0L).build();
        client.load(request);
        Toast.makeText(this, "Casting: " + title, 0).show();
    }

    private String guessMime(String url) {
        return guessMime(url, false);
    }

    private String guessMime(String url, boolean music) {
        String lower = url.toLowerCase();
        if (music) {
            if (lower.contains(".flac")) return "audio/flac";
            if (lower.contains(".m4a") || lower.contains(".aac")) return "audio/mp4";
            if (lower.contains(".ogg") || lower.contains(".opus")) return "audio/ogg";
            return "audio/mpeg";
        }
        return lower.contains(".zip") ? "application/zip" : lower.contains(".m3u8") ? "application/x-mpegURL" : lower.contains(".webm") ? "video/webm" : lower.contains(".mkv") ? "video/x-matroska" : lower.contains(".avi") ? "video/x-msvideo" : "video/mp4";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String absolutize(String url) {
        if (url == null || url.trim().isEmpty()) {
            return "";
        }
        Uri uri = Uri.parse(url.trim());
        if (uri.isAbsolute()) {
            return url.trim();
        }
        Uri base = Uri.parse(this.webView.getUrl() != null ? this.webView.getUrl() : normalizedServerUrl());
        return base.buildUpon().path(uri.getPath()).encodedQuery(uri.getEncodedQuery()).build().toString();
    }

    private String stripJsString(String value) {
        if (value == null || "null".equals(value)) {
            return "{}";
        }
        if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
            return value.substring(1, value.length() - 1).replace("\\\\", "\\").replace("\\\"", "\"").replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t");
        }
        return value;
    }

    private void musicCommand(String action) {
        startMusicService(new Intent(this, MusicPlaybackService.class).setAction(action));
    }

    private void startMusicService(Intent intent) {
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private class MusicBridge {
        @JavascriptInterface
        public void playQueue(final String queueJson, final int index, final double positionSeconds,
                              final boolean shuffle, final String repeatMode) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    String currentUrl = webView.getUrl() != null ? webView.getUrl() : normalizedServerUrl();
                    Intent intent = new Intent(MainActivity.this, MusicPlaybackService.class)
                            .setAction(MusicPlaybackService.ACTION_PLAY_QUEUE)
                            .putExtra("queue_json", queueJson)
                            .putExtra("index", index)
                            .putExtra("position_ms", (long) (Math.max(0.0d, positionSeconds) * 1000.0d))
                            .putExtra("base_url", currentUrl)
                            .putExtra("cookie", CookieManager.getInstance().getCookie(currentUrl))
                            .putExtra("shuffle", shuffle)
                            .putExtra("repeat_mode", repeatMode == null ? "off" : repeatMode);
                    startMusicService(intent);
                }
            });
        }

        @JavascriptInterface public void toggle() { runOnUiThread(new Runnable() { @Override public void run() { musicCommand(MusicPlaybackService.ACTION_TOGGLE); }}); }
        @JavascriptInterface public void seekTo(final double seconds) { runOnUiThread(new Runnable() { @Override public void run() {
            startMusicService(new Intent(MainActivity.this, MusicPlaybackService.class).setAction(MusicPlaybackService.ACTION_SEEK)
                    .putExtra("position_ms", (long) (Math.max(0.0d, seconds) * 1000.0d)));
        }}); }
        @JavascriptInterface public void setRepeatMode(final String mode) { runOnUiThread(new Runnable() { @Override public void run() {
            startMusicService(new Intent(MainActivity.this, MusicPlaybackService.class).setAction(MusicPlaybackService.ACTION_REPEAT).putExtra("mode", mode));
        }}); }
        @JavascriptInterface public void setShuffle(final boolean enabled) { runOnUiThread(new Runnable() { @Override public void run() {
            startMusicService(new Intent(MainActivity.this, MusicPlaybackService.class).setAction(MusicPlaybackService.ACTION_SHUFFLE).putExtra("enabled", enabled));
        }}); }
        @JavascriptInterface public void stop() { runOnUiThread(new Runnable() { @Override public void run() { musicCommand(MusicPlaybackService.ACTION_STOP); }}); }
        @JavascriptInterface public double getDuration() {
            return getSharedPreferences(MusicPlaybackService.PREFS, MODE_PRIVATE).getLong("duration", 0L) / 1000.0d;
        }
        @JavascriptInterface public void castCurrent() { runOnUiThread(new Runnable() { @Override public void run() { castCurrentVideo(); }}); }
    }

    private void pushNativeMusicState() {
        if (webView == null || webView.getUrl() == null || !webView.getUrl().contains("/music")) return;
        SharedPreferences state = getSharedPreferences(MusicPlaybackService.PREFS, MODE_PRIVATE);
        try {
            JSONObject payload = new JSONObject();
            payload.put("position", state.getLong("position", 0L) / 1000.0d);
            payload.put("duration", state.getLong("duration", 0L) / 1000.0d);
            payload.put("index", state.getInt("index", -1));
            payload.put("playing", state.getBoolean("playing", false));
            webView.evaluateJavascript("window.cineVaultNativeState&&window.cineVaultNativeState(" + JSONObject.quote(payload.toString()) + ")", null);
        } catch (Exception ignored) {
        }
    }

    private void requestOfflineMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.READ_MEDIA_VIDEO") != 0) {
            requestPermissions(new String[]{"android.permission.READ_MEDIA_VIDEO"}, 50);
        } else if (Build.VERSION.SDK_INT < 33 && checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
            requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 51);
        }
    }

    private String classifyDownload(String url, String metadataJson) {
        String lower = (url + " " + metadataJson).toLowerCase(Locale.US);
        if (lower.contains("/download/season") || lower.contains("season zip") || lower.contains("season downloads") || lower.contains("/tv/") || lower.contains("episode") || lower.contains("season") || lower.contains("/download/episode")) {
            return "tv";
        }
        return "movie";
    }

    private void rememberOfflineDownload(String kind, String folder, String filename, String sourceUrl, String metadataJson) {
        rememberOfflineDownload(kind, folder, filename, sourceUrl, metadataJson, new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), folder + "/" + filename).getAbsolutePath());
    }

    private void rememberOfflineDownload(String kind, String folder, String filename, String sourceUrl, String metadataJson, String savedPath) {
        try {
            JSONObject metadata = new JSONObject((metadataJson == null || !metadataJson.trim().startsWith("{")) ? "{}" : metadataJson);
            String metadataTitle = metadata.optString("title", "");
            if (isGenericTitle(metadataTitle)) {
                metadataTitle = niceTitleFromFile(filename);
            }
            String poster = metadata.optString("poster", "");
            String localPoster = cachePoster(poster, filename);
            JSONObject entry = new JSONObject();
            entry.put("kind", kind);
            entry.put("folder", folder);
            entry.put("filename", filename);
            entry.put("path", savedPath);
            entry.put("sourceUrl", sourceUrl);
            entry.put("title", metadataTitle);
            entry.put(MediaTrack.ROLE_SUBTITLE, metadata.optString(MediaTrack.ROLE_SUBTITLE, ""));
            entry.put("summary", metadata.optString("summary", ""));
            entry.put("poster", !localPoster.isEmpty() ? localPoster : makeAbsoluteUrlNoWebView(poster));
            entry.put("page", metadata.optString("page", normalizedServerUrl()));
            entry.put("savedAt", System.currentTimeMillis());
            FileWriter writer = new FileWriter(new File(getFilesDir(), OFFLINE_INDEX_FILE), true);
            writer.write(entry.toString());
            writer.write("\n");
            writer.close();
        } catch (Exception ignored) {
        }
    }

    private boolean isGenericTitle(String title) {
        if (title == null) {
            return true;
        }
        String cleaned = title.trim();
        return cleaned.isEmpty() || cleaned.matches("[0-9]+") || cleaned.equalsIgnoreCase("download");
    }

    private String makeAbsoluteUrlNoWebView(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "";
        }
        try {
            Uri uri = Uri.parse(value.trim());
            if (uri.isAbsolute()) {
                return value.trim();
            }
            Uri base = Uri.parse(normalizedServerUrl());
            return base.buildUpon().path(uri.getPath()).encodedQuery(uri.getEncodedQuery()).build().toString();
        } catch (Exception e) {
            return value;
        }
    }

    private String cachePoster(String posterUrl, String filename) {
        String absolute = makeAbsoluteUrlNoWebView(posterUrl);
        if (absolute.isEmpty()) {
            return "";
        }
        try {
            File posterDir = new File(getFilesDir(), "offline_posters");
            if (!posterDir.exists()) {
                posterDir.mkdirs();
            }
            File out = new File(posterDir, sanitizeFilename(stripKnownExtension(filename)) + ".jpg");
            HttpURLConnection connection = (HttpURLConnection) new URL(absolute).openConnection();
            if ((connection instanceof HttpsURLConnection) && isConfiguredServerUrl(absolute)) {
                HttpsURLConnection https = (HttpsURLConnection) connection;
                https.setSSLSocketFactory(trustAllSslContext().getSocketFactory());
                https.setHostnameVerifier(new HostnameVerifier() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda33
                    @Override // javax.net.ssl.HostnameVerifier
                    public final boolean verify(String str, SSLSession sSLSession) {
                        return MainActivity.lambda$cachePoster$14(str, sSLSession);
                    }
                });
            }
            connection.setConnectTimeout(RouteListingPreference.Item.SUBTEXT_CUSTOM);
            connection.setReadTimeout(15000);
            InputStream input = connection.getInputStream();
            FileOutputStream output = new FileOutputStream(out);
            byte[] buffer = new byte[32768];
            while (true) {
                int read = input.read(buffer);
                if (read != -1) {
                    output.write(buffer, 0, read);
                } else {
                    output.close();
                    input.close();
                    connection.disconnect();
                    return Uri.fromFile(out).toString();
                }
            }
        } catch (Exception e) {
            return "";
        }
    }

    static /* synthetic */ boolean lambda$cachePoster$14(String hostname, SSLSession session) {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showOfflineLibrary(String reason) {
        String str;
        this.offlineMode = true;
        List<JSONObject> items = offlineItems();
        StringBuilder cards = new StringBuilder();
        Iterator<JSONObject> it = items.iterator();
        while (true) {
            str = "";
            if (!it.hasNext()) {
                break;
            }
            JSONObject item = it.next();
            String title = item.optString("title", niceTitleFromFile(item.optString("filename", "")));
            String subtitle = item.optString(MediaTrack.ROLE_SUBTITLE, item.optString("kind", ""));
            String summary = item.optString("summary", "");
            String path = item.optString("path", "");
            String poster = item.optString("poster", "");
            String posterStyle = poster.isEmpty() ? "" : " style=\"background-image:url('" + escapeCssUrl(poster) + "')\"";
            StringBuilder sbAppend = cards.append("<a class='card' href='cinevault://play-offline?path=").append(Uri.encode(path)).append("&title=").append(Uri.encode(title)).append("'>").append("<div class='poster'").append(posterStyle).append(">").append(poster.isEmpty() ? "<span>No Poster</span>" : "").append("</div><div class='copy'><strong>").append(escapeHtml(title)).append("</strong><small>").append(escapeHtml(subtitle)).append("</small>");
            if (!summary.isEmpty()) {
                str = "<p>" + escapeHtml(summary) + "</p>";
            }
            sbAppend.append(str).append("<em>Tap to play offline</em>").append("<span class='delete' onclick=\"event.preventDefault();event.stopPropagation();location.href='cinevault://delete-offline?path=").append(Uri.encode(path)).append("'\">Delete offline</span></div></a>");
        }
        String empty = items.isEmpty() ? "<div class='empty'>No offline movies or TV episodes found yet.<br>Downloads should live in Downloads/CineVault/Movies or Downloads/CineVault/TV_Shows.</div>" : "";
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{margin:0;background:#050506;color:#fff;font-family:Arial,sans-serif;padding:24px 18px 80px}.top{display:flex;align-items:center;justify-content:space-between;gap:12px}.logo{font-size:30px;font-weight:900}.logo span{color:#f5b73f}.actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.pill{border:1px solid rgba(255,255,255,.18);border-radius:999px;background:#1a1f28;color:#fff;padding:10px 14px;text-decoration:none;font-weight:800}.reason{color:#aeb6c4;margin:8px 0 16px}.hint{color:#8f98a8;margin:0 0 24px;font-size:13px}.grid{display:grid;gap:14px}.card{color:#fff;text-decoration:none;border:1px solid rgba(255,255,255,.12);background:#111720;border-radius:18px;padding:12px;display:grid;grid-template-columns:88px 1fr;gap:14px;align-items:start}.poster{width:88px;aspect-ratio:2/3;border-radius:10px;background:#121820 center/cover no-repeat;border:1px solid rgba(255,255,255,.14);display:grid;place-items:center;color:#9aa3b3;text-align:center;font-size:12px}strong{display:block;font-size:20px;line-height:1.08}small{display:block;color:#aeb6c4;margin-top:4px}.copy p{margin:9px 0 0;color:#d7dbe3;line-height:1.28;max-height:3.9em;overflow:hidden}.copy em{display:inline-block;margin-top:10px;color:#f5b73f;font-style:normal;font-weight:900}.delete{display:inline-block;margin-left:12px;margin-top:10px;border:1px solid rgba(255,95,95,.5);color:#ffb3b3;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:900}.empty{border:1px dashed rgba(255,255,255,.2);border-radius:18px;padding:18px;color:#b9c0cc;line-height:1.35}@media(min-width:720px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}body{padding:32px}.card{grid-template-columns:110px 1fr}.poster{width:110px}}</style></head><body><div class='top'><div class='logo'>Cine<span>Media</span>Vault Offline</div><div class='actions'><a class='pill' href='cinevault://set-offline-folder'>Change Save Folder</a><a class='pill' href='cinevault://try-server'>Try Server</a></div></div><div class='reason'>Server unavailable: " + escapeHtml(reason != null ? reason : "offline") + "</div><div class='hint'>Movies and TV shows are shown from the APK offline index and selected save folder.</div>" + empty + "<div class='grid'>" + ((Object) cards) + "</div></body></html>";
        this.webView.loadDataWithBaseURL("file:///", html, "text/html", "UTF-8", null);
        scheduleOfflineReconnectCheck();
    }

    private List<JSONObject> offlineItems() {
        List<JSONObject> items = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        File index = new File(getFilesDir(), OFFLINE_INDEX_FILE);
        if (index.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(openFileInput(OFFLINE_INDEX_FILE)));
                while (true) {
                    String line = reader.readLine();
                    if (line == null) {
                        break;
                    }
                    JSONObject item = new JSONObject(line);
                    String path = item.optString("path", "");
                    if (!path.isEmpty() && pathExists(path) && seen.add(path)) {
                        items.add(item);
                    }
                }
                reader.close();
            } catch (Exception e) {
            }
        }
        scanOfflineFolder(items, seen, MOVIE_DOWNLOAD_DIR, "movie");
        scanOfflineFolder(items, seen, TV_DOWNLOAD_DIR, "tv");
        return items;
    }

    private void scanOfflineFolder(List<JSONObject> items, Set<String> seen, String subdir, String kind) {
        File rootDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), subdir);
        scanOfflineFolderRecursive(items, seen, rootDir, kind);
    }

    private void scanOfflineFolderRecursive(List<JSONObject> items, Set<String> seen, File dir, String kind) {
        File[] files = dir.listFiles();
        if (files == null) {
            return;
        }
        for (File file : files) {
            if (file.isDirectory()) {
                scanOfflineFolderRecursive(items, seen, file, kind);
            } else if (isVideoFile(file.getName()) && seen.add(file.getAbsolutePath())) {
                try {
                    JSONObject item = new JSONObject();
                    item.put("kind", kind);
                    item.put("path", file.getAbsolutePath());
                    item.put("filename", file.getName());
                    item.put("title", niceTitleFromFile(file.getName()));
                    item.put(MediaTrack.ROLE_SUBTITLE, kind.equals("tv") ? "TV Show" : "Movie");
                    items.add(item);
                } catch (Exception e) {
                }
            }
        }
    }

    private boolean isVideoFile(String name) {
        String lower = name.toLowerCase(Locale.US);
        return lower.endsWith(".mp4") || lower.endsWith(".m4v") || lower.endsWith(".webm") || lower.endsWith(".mkv") || lower.endsWith(".avi") || lower.endsWith(".mov") || lower.endsWith(".bin") || lower.endsWith(".zip");
    }

    private String niceTitleFromFile(String filename) {
        String value = filename == null ? "" : filename;
        int dot = value.lastIndexOf(46);
        if (dot > 0) {
            value = value.substring(0, dot);
        }
        String value2 = value.replace('_', ' ').replace('.', ' ').replaceAll("\\s+", " ").trim();
        return value2.isEmpty() ? "Offline Video" : value2;
    }

    private String escapeCssUrl(String value) {
        return escapeHtml(value).replace("'", "%27");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playOffline(Uri uri) {
        String path = uri.getQueryParameter("path");
        String title = uri.getQueryParameter("title");
        if (path == null || path.trim().isEmpty() || !pathExists(path)) {
            Toast.makeText(this, "Offline file not found.", 1).show();
            showOfflineLibrary("Offline file missing");
        } else {
            if (path.toLowerCase(Locale.US).endsWith(".zip")) {
                Toast.makeText(this, "Season ZIP is saved offline, but ZIP files are not playable directly.", 1).show();
                return;
            }
            String fileUrl = path.startsWith("content://") ? path : Uri.fromFile(new File(path)).toString();
            String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>html,body{margin:0;height:100%;background:#000;color:#fff;font-family:Arial,sans-serif;overflow:hidden}.bar{position:fixed;left:0;right:0;top:0;z-index:2;padding:12px 14px;background:linear-gradient(rgba(0,0,0,.72),rgba(0,0,0,0));display:flex;justify-content:space-between;align-items:center}a{color:#fff;text-decoration:none;font-weight:900}.title{font-weight:900;max-width:70%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}video{width:100vw;height:100vh;background:#000}</style></head><body><div class='bar'><a href='cinevault://offline'>&larr; Offline</a><div class='title'>" + escapeHtml(title != null ? title : niceTitleFromFile(path)) + "</div></div><video src='" + escapeHtml(fileUrl) + "' controls autoplay playsinline></video></body></html>";
            this.webView.loadDataWithBaseURL("file:///", html, "text/html", "UTF-8", null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deleteOffline(Uri uri) {
        String path = uri.getQueryParameter("path");
        if (path == null || path.trim().isEmpty()) {
            showOfflineLibrary("Offline item missing");
            return;
        }
        boolean deleted = false;
        try {
            boolean z = true;
            if (path.startsWith("content://")) {
                DocumentFile file = DocumentFile.fromSingleUri(this, Uri.parse(path));
                if (file == null || !file.delete()) {
                    z = false;
                }
                deleted = z;
            } else {
                File file2 = new File(path);
                if (file2.exists() && !file2.delete()) {
                    z = false;
                }
                deleted = z;
            }
        } catch (Exception e) {
        }
        removeOfflineEntry(path);
        Toast.makeText(this, deleted ? "Offline item deleted." : "Offline entry removed.", 0).show();
        showOfflineLibrary("Offline library");
    }

    private void removeOfflineEntry(String path) {
        if (path == null || path.trim().isEmpty()) {
            return;
        }
        File index = new File(getFilesDir(), OFFLINE_INDEX_FILE);
        if (index.exists()) {
            List<String> keep = new ArrayList<>();
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(openFileInput(OFFLINE_INDEX_FILE)));
                String line;
                while ((line = reader.readLine()) != null) {
                    try {
                        JSONObject item = new JSONObject(line);
                        if (!path.equals(item.optString("path", ""))) {
                            keep.add(line);
                        }
                    } catch (Exception ignored) {
                        keep.add(line);
                    }
                }
                reader.close();
                FileOutputStream output = openFileOutput(OFFLINE_INDEX_FILE, 0);
                for (String keptLine : keep) {
                    output.write(keptLine.getBytes("UTF-8"));
                    output.write(10);
                }
                output.close();
            } catch (Exception e) {
                return;
            }
        }
    }

    private boolean pathExists(String path) {
        if (path == null || path.trim().isEmpty()) {
            return false;
        }
        try {
            if (path.startsWith("content://")) {
                InputStream input = getContentResolver().openInputStream(Uri.parse(path));
                if (input == null) {
                    return false;
                }
                input.close();
                return true;
            }
            return new File(path).exists();
        } catch (Exception e) {
            return false;
        }
    }

    private void scheduleOfflineReconnectCheck() {
        this.offlineHandler.removeCallbacksAndMessages(null);
        if (hasServerUrl()) {
            this.offlineHandler.postDelayed(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda34
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m52xce140e67();
                }
            }, NotificationOptions.SKIP_STEP_THIRTY_SECONDS_IN_MS);
        }
    }

    /* JADX INFO: renamed from: lambda$scheduleOfflineReconnectCheck$17$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m52xce140e67() {
        if (this.offlineMode) {
            new Thread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m51x6cc171c8();
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$scheduleOfflineReconnectCheck$16$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m51x6cc171c8() {
        final boolean reachable = isServerReachable();
        runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m50xb6ed529(reachable);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$scheduleOfflineReconnectCheck$15$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m50xb6ed529(boolean reachable) {
        if (reachable && this.offlineMode) {
            this.offlineMode = false;
            Toast.makeText(this, "CineMediaVault server is back online.", 0).show();
            loadHome();
        } else if (this.offlineMode) {
            scheduleOfflineReconnectCheck();
        }
    }

    private boolean isServerReachable() {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(normalizedServerUrl()).openConnection();
            if (connection instanceof HttpsURLConnection) {
                HttpsURLConnection https = (HttpsURLConnection) connection;
                https.setSSLSocketFactory(trustAllSslContext().getSocketFactory());
                https.setHostnameVerifier(new HostnameVerifier() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda19
                    @Override // javax.net.ssl.HostnameVerifier
                    public final boolean verify(String str, SSLSession sSLSession) {
                        return MainActivity.lambda$isServerReachable$18(str, sSLSession);
                    }
                });
            }
            connection.setConnectTimeout(PathInterpolatorCompat.MAX_NUM_POINTS);
            connection.setReadTimeout(PathInterpolatorCompat.MAX_NUM_POINTS);
            connection.setRequestMethod("GET");
            int code = connection.getResponseCode();
            connection.disconnect();
            return code > 0 && code < 500;
        } catch (Exception e) {
            return false;
        }
    }

    static /* synthetic */ boolean lambda$isServerReachable$18(String hostname, SSLSession session) {
        return true;
    }

    private SSLContext trustAllSslContext() throws Exception {
        TrustManager[] managers = {new X509TrustManager() { // from class: com.cinevault.companion.MainActivity.4
            @Override // javax.net.ssl.X509TrustManager
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            @Override // javax.net.ssl.X509TrustManager
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @Override // javax.net.ssl.X509TrustManager
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }
        }};
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(null, managers, new SecureRandom());
        return context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadHome() {
        if (!hasServerUrl()) {
            showServerDialog(true);
            return;
        }
        this.offlineMode = false;
        this.offlineHandler.removeCallbacksAndMessages(null);
        new Thread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda23
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m46lambda$loadHome$20$comcinevaultcompanionMainActivity();
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$loadHome$20$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m46lambda$loadHome$20$comcinevaultcompanionMainActivity() {
        final boolean reachable = isServerReachable();
        runOnUiThread(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m45lambda$loadHome$19$comcinevaultcompanionMainActivity(reachable);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadHome$19$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m45lambda$loadHome$19$comcinevaultcompanionMainActivity(boolean reachable) {
        if (reachable) {
            this.webView.loadUrl(normalizedServerUrl());
        } else {
            showOfflineLibrary("Server not reachable");
        }
    }

    private void maybePromptOfflineFolderThenLoad() {
        if (selectedOfflineTree() != null || this.prefs.getBoolean(KEY_OFFLINE_FOLDER_PROMPTED, false)) {
            loadHome();
        } else {
            this.prefs.edit().putBoolean(KEY_OFFLINE_FOLDER_PROMPTED, true).apply();
            new AlertDialog.Builder(this).setTitle("Offline Save Folder").setMessage("Choose one parent folder for offline saves. CineMediaVault will create Movies and TV_Shows under it.").setPositiveButton("Choose Folder", new DialogInterface.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda27
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m47xdafed353(dialogInterface, i);
                }
            }).setNegativeButton("Skip", new DialogInterface.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda28
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m48x3c516ff2(dialogInterface, i);
                }
            }).show();
        }
    }

    /* JADX INFO: renamed from: lambda$maybePromptOfflineFolderThenLoad$21$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m47xdafed353(DialogInterface dialog, int which) {
        chooseOfflineFolder();
    }

    /* JADX INFO: renamed from: lambda$maybePromptOfflineFolderThenLoad$22$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m48x3c516ff2(DialogInterface dialog, int which) {
        loadHome();
    }

    private void loadHomeWithoutProbe() {
        if (!hasServerUrl()) {
            showServerDialog(true);
            return;
        }
        this.offlineMode = false;
        this.offlineHandler.removeCallbacksAndMessages(null);
        this.webView.loadUrl(normalizedServerUrl());
    }

    private boolean hasServerUrl() {
        String value = this.prefs.getString(KEY_SERVER, "");
        return (value == null || value.trim().isEmpty()) ? false : true;
    }

    private String normalizedServerUrl() {
        String value = this.prefs.getString(KEY_SERVER, "").trim();
        if (!value.startsWith("http://") && !value.startsWith("https://")) {
            Uri probe = Uri.parse("http://" + value);
            int port = probe.getPort();
            value = ((port == 5000 || port == 443) ? new StringBuilder().append("https://") : new StringBuilder().append("http://")).append(value).toString();
        }
        Uri uri = Uri.parse(value);
        if (uri.getPort() == -1 && uri.getHost() != null && !uri.getHost().isEmpty()) {
            int defaultPort = "https".equalsIgnoreCase(uri.getScheme()) ? 443 : 8093;
            Uri.Builder builder = uri.buildUpon().encodedAuthority(uri.getHost() + ":" + defaultPort);
            value = builder.build().toString();
        }
        if (!value.endsWith("/")) {
            return value + "/";
        }
        return value;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isConfiguredServerUrl(String url) {
        if (url == null || url.trim().isEmpty() || !hasServerUrl()) {
            return false;
        }
        try {
            Uri configured = Uri.parse(normalizedServerUrl());
            Uri requested = Uri.parse(url);
            String configuredHost = configured.getHost();
            String requestedHost = requested.getHost();
            if (configuredHost != null && requestedHost != null && configuredHost.equalsIgnoreCase(requestedHost)) {
                int configuredPort = configured.getPort();
                int requestedPort = requested.getPort();
                int i = 443;
                if (configuredPort == -1) {
                    configuredPort = "https".equalsIgnoreCase(configured.getScheme()) ? 443 : REQUEST_OFFLINE_FOLDER;
                }
                if (requestedPort == -1) {
                    if (!"https".equalsIgnoreCase(requested.getScheme())) {
                        i = REQUEST_OFFLINE_FOLDER;
                    }
                    requestedPort = i;
                }
                if (configuredPort == requestedPort) {
                    return "https".equalsIgnoreCase(requested.getScheme());
                }
                return false;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showWebErrorPage(String title, String detail) {
        String safeTitle = escapeHtml(title);
        String safeDetail = escapeHtml(detail != null ? detail : "");
        String server = escapeHtml(normalizedServerUrl());
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{margin:0;min-height:100vh;background:#050506;color:#fff;font-family:Arial,sans-serif;display:grid;place-items:center;padding:24px}.card{max-width:440px;width:100%;border:1px solid rgba(255,255,255,.18);border-radius:20px;background:#11151d;padding:22px}h1{margin:0 0 10px;font-size:24px}.muted{color:#b8c0cc;line-height:1.35}.btn{display:inline-block;margin-top:18px;border-radius:999px;background:#f5b73f;color:#111;padding:12px 18px;font-weight:900;text-decoration:none}</style></head><body><div class='card'><h1>" + safeTitle + "</h1><div class='muted'>Server: " + server + "</div><p class='muted'>" + safeDetail + "</p><a class='btn' href='cinevault://set-server'>Set Server</a></div></body></html>";
        this.webView.loadDataWithBaseURL(normalizedServerUrl(), html, "text/html", "UTF-8", null);
    }

    private String escapeHtml(String value) {
        return value == null ? "" : value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private void showServerDialog() {
        showServerDialog(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showServerDialog(boolean required) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Examples: 192.168.1.20:8093 or https://192.168.1.20:5000");
        input.setText(hasServerUrl() ? normalizedServerUrl() : "");
        input.setSelection(input.getText().length());
        AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle("CineMediaVault Server").setMessage("Enter your server address. Example: 192.168.1.20:8093").setView(input).setPositiveButton("Save", new DialogInterface.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m61lambda$showServerDialog$23$comcinevaultcompanionMainActivity(input, dialogInterface, i);
            }
        });
        if (required) {
            builder.setNegativeButton("Exit", new DialogInterface.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda11
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m62lambda$showServerDialog$24$comcinevaultcompanionMainActivity(dialogInterface, i);
                }
            });
        } else {
            builder.setNegativeButton("Cancel", (DialogInterface.OnClickListener) null);
        }
        builder.show();
    }

    /* JADX INFO: renamed from: lambda$showServerDialog$23$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m61lambda$showServerDialog$23$comcinevaultcompanionMainActivity(EditText input, DialogInterface dialog, int which) {
        String value = input.getText().toString().trim();
        if (value.isEmpty()) {
            Toast.makeText(this, "Server URL is required.", 1).show();
            showServerDialog(true);
        } else {
            this.prefs.edit().putString(KEY_SERVER, value).apply();
            maybePromptOfflineFolderThenLoad();
        }
    }

    /* JADX INFO: renamed from: lambda$showServerDialog$24$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m62lambda$showServerDialog$24$comcinevaultcompanionMainActivity(DialogInterface dialog, int which) {
        finish();
    }

    private void openExternal() {
        if (!hasServerUrl()) {
            showServerDialog(true);
        } else {
            String url = this.webView.getUrl() != null ? this.webView.getUrl() : normalizedServerUrl();
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    private void goBack() {
        if (this.introOverlay != null) {
            hideIntroOverlay();
            return;
        }
        if (this.customVideoView != null) {
            hideCustomVideoView();
        } else if (this.webView.canGoBack()) {
            this.webView.goBack();
        } else {
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean shouldPlayIntroForUrl(String url) {
        if (url == null) {
            return false;
        }
        Uri uri = Uri.parse(url);
        String path = uri.getPath();
        if (path != null && path.startsWith("/login")) {
            this.sawLoginPage = true;
            return false;
        }
        if (!this.sawLoginPage || this.introPlayedAfterLogin) {
            return false;
        }
        this.sawLoginPage = false;
        this.introPlayedAfterLogin = true;
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showIntroOverlay() {
        if (this.introOverlay != null) {
            return;
        }
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        overlay.setClickable(true);
        overlay.setAlpha(1.0f);
        final VideoView introVideo = new VideoView(this);
        introVideo.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.cinemediavault_intro));
        introVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda22
            @Override // android.media.MediaPlayer.OnPreparedListener
            public final void onPrepared(MediaPlayer mediaPlayer) {
                MainActivity.this.m56lambda$showIntroOverlay$26$comcinevaultcompanionMainActivity(overlay, introVideo, mediaPlayer);
            }
        });
        introVideo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda29
            @Override // android.media.MediaPlayer.OnCompletionListener
            public final void onCompletion(MediaPlayer mediaPlayer) {
                MainActivity.this.m57lambda$showIntroOverlay$27$comcinevaultcompanionMainActivity(mediaPlayer);
            }
        });
        introVideo.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda30
            @Override // android.media.MediaPlayer.OnErrorListener
            public final boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                return MainActivity.this.m58lambda$showIntroOverlay$28$comcinevaultcompanionMainActivity(mediaPlayer, i, i2);
            }
        });
        overlay.addView(introVideo, new FrameLayout.LayoutParams(-1, -1, 17));
        final View whiteFlash = new View(this);
        whiteFlash.setBackgroundColor(-1);
        overlay.addView(whiteFlash, new FrameLayout.LayoutParams(-1, -1));
        this.introHandler.postDelayed(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda31
            @Override // java.lang.Runnable
            public final void run() {
                View view = whiteFlash;
                view.animate().alpha(0.0f).setDuration(120L).withEndAction(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        overlay.removeView(view);
                    }
                }).start();
            }
        }, 200L);
        LinearLayout logo = buildIntroLogo();
        FrameLayout.LayoutParams logoParams = new FrameLayout.LayoutParams(-2, -2);
        logoParams.gravity = 51;
        logoParams.setMargins(dp(24), dp(24), dp(24), dp(24));
        overlay.addView(logo, logoParams);
        TextView skip = new TextView(this);
        skip.setText("Tap to skip");
        skip.setTextColor(Color.argb(175, 255, 255, 255));
        skip.setTextSize(12.0f);
        skip.setGravity(17);
        FrameLayout.LayoutParams skipParams = new FrameLayout.LayoutParams(-2, -2);
        skipParams.gravity = 81;
        skipParams.setMargins(0, 0, 0, dp(22));
        overlay.addView(skip, skipParams);
        overlay.setOnClickListener(new View.OnClickListener() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda32
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m59lambda$showIntroOverlay$31$comcinevaultcompanionMainActivity(view);
            }
        });
        this.introOverlay = overlay;
        this.webView.setVisibility(4);
        this.menuButton.setVisibility(8);
        this.castLaunchButton.setVisibility(8);
        this.root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        enterImmersiveMode();
    }

    /* JADX INFO: renamed from: lambda$showIntroOverlay$26$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m56lambda$showIntroOverlay$26$comcinevaultcompanionMainActivity(final FrameLayout overlay, final VideoView introVideo, MediaPlayer player) {
        player.setLooping(false);
        player.setVolume(1.0f, 1.0f);
        this.introHandler.postDelayed(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda35
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m55lambda$showIntroOverlay$25$comcinevaultcompanionMainActivity(overlay, introVideo);
            }
        }, 200L);
    }

    /* JADX INFO: renamed from: lambda$showIntroOverlay$25$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m55lambda$showIntroOverlay$25$comcinevaultcompanionMainActivity(FrameLayout overlay, VideoView introVideo) {
        if (this.introOverlay == overlay) {
            introVideo.start();
        }
    }

    /* JADX INFO: renamed from: lambda$showIntroOverlay$27$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m57lambda$showIntroOverlay$27$comcinevaultcompanionMainActivity(MediaPlayer player) {
        this.introHandler.postDelayed(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda24
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.dissolveIntroOverlay();
            }
        }, 1700L);
    }

    /* JADX INFO: renamed from: lambda$showIntroOverlay$28$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ boolean m58lambda$showIntroOverlay$28$comcinevaultcompanionMainActivity(MediaPlayer player, int what, int extra) {
        hideIntroOverlay();
        return true;
    }

    /* JADX INFO: renamed from: lambda$showIntroOverlay$31$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m59lambda$showIntroOverlay$31$comcinevaultcompanionMainActivity(View v) {
        hideIntroOverlay();
    }

    private LinearLayout buildIntroLogo() {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(0);
        wrapper.setGravity(16);
        wrapper.setPadding(dp(10), dp(8), dp(10), dp(8));
        wrapper.setBackgroundColor(Color.argb(AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR, 0, 0, 0));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(1);
        left.setGravity(3);
        TextView cine = logoWord("CINE", -1);
        TextView media = logoWord("MEDIA", -1);
        left.addView(cine);
        left.addView(media);
        wrapper.addView(left);
        View divider = new View(this);
        divider.setBackgroundColor(Color.argb(210, 255, 255, 255));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(dp(2), dp(52));
        dividerParams.setMargins(dp(9), 0, dp(9), 0);
        wrapper.addView(divider, dividerParams);
        TextView vault = logoWord("VAULT", Color.rgb(198, 255, 0));
        wrapper.addView(vault);
        VaultWheelView wheel = new VaultWheelView(this, Color.rgb(198, 255, 0));
        LinearLayout.LayoutParams wheelParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        wheelParams.setMargins(dp(12), 0, 0, 0);
        wrapper.addView(wheel, wheelParams);
        return wrapper;
    }

    private TextView logoWord(String text, int color) {
        TextView word = new TextView(this);
        word.setText(text);
        word.setTextColor(color);
        word.setTextSize(25.0f);
        word.setLetterSpacing(0.03f);
        word.setTypeface(Typeface.DEFAULT_BOLD);
        word.setIncludeFontPadding(false);
        return word;
    }

    private SpannableString coloredCmV() {
        SpannableString value = new SpannableString("CmV");
        int yellow = Color.rgb(245, 183, 63);
        value.setSpan(new ForegroundColorSpan(yellow), 0, 1, 33);
        value.setSpan(new ForegroundColorSpan(-1), 1, 2, 33);
        value.setSpan(new ForegroundColorSpan(yellow), 2, 3, 33);
        return value;
    }

    private static class VaultWheelView extends View {
        private final int accent;
        private final Paint paint;

        VaultWheelView(Context context, int accent) {
            super(context);
            this.paint = new Paint(1);
            this.accent = accent;
            this.paint.setStrokeCap(Paint.Cap.ROUND);
            this.paint.setStyle(Paint.Style.STROKE);
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2.0f;
            float cy = h / 2.0f;
            float radius = Math.min(w, h) * 0.42f;
            this.paint.setColor(this.accent);
            this.paint.setStrokeWidth(Math.max(3.0f, 0.07f * w));
            canvas.drawCircle(cx, cy, radius, this.paint);
            canvas.drawCircle(cx, cy, 0.3f * radius, this.paint);
            for (int i = 0; i < 8; i++) {
                double angle = Math.toRadians(i * 45);
                float inner = radius * 0.46f;
                float outer = radius * 0.84f;
                float x1 = cx + (((float) Math.cos(angle)) * inner);
                float y1 = cy + (((float) Math.sin(angle)) * inner);
                float x2 = cx + (((float) Math.cos(angle)) * outer);
                float y2 = cy + (((float) Math.sin(angle)) * outer);
                canvas.drawLine(x1, y1, x2, y2, this.paint);
            }
            this.paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy, 0.1f * radius, this.paint);
            this.paint.setStyle(Paint.Style.STROKE);
        }
    }

    private void hideIntroOverlay() {
        if (this.introOverlay == null) {
            return;
        }
        this.introHandler.removeCallbacksAndMessages(null);
        this.root.removeView(this.introOverlay);
        this.introOverlay = null;
        this.webView.setVisibility(0);
        this.menuButton.setVisibility(0);
        this.castLaunchButton.setVisibility(0);
        enterImmersiveMode();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dissolveIntroOverlay() {
        if (this.introOverlay == null) {
            return;
        }
        final View overlay = this.introOverlay;
        if (overlay instanceof FrameLayout) {
            ParticleDissolveView particles = new ParticleDissolveView(this);
            ((FrameLayout) overlay).addView(particles, new FrameLayout.LayoutParams(-1, -1));
            particles.start();
        }
        overlay.animate().alpha(0.0f).setDuration(950L).withEndAction(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m43x2927e1a0(overlay);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$dissolveIntroOverlay$32$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m43x2927e1a0(View overlay) {
        if (this.introOverlay == overlay) {
            this.root.removeView(overlay);
            this.introOverlay = null;
        }
        showBlackThenHome();
    }

    private void showBlackThenHome() {
        final View black = new View(this);
        black.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        black.setAlpha(1.0f);
        this.root.addView(black, new FrameLayout.LayoutParams(-1, -1));
        this.webView.setVisibility(0);
        this.menuButton.setVisibility(0);
        this.castLaunchButton.setVisibility(0);
        this.introHandler.postDelayed(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m54lambda$showBlackThenHome$34$comcinevaultcompanionMainActivity(black);
            }
        }, 180L);
    }

    /* JADX INFO: renamed from: lambda$showBlackThenHome$34$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m54lambda$showBlackThenHome$34$comcinevaultcompanionMainActivity(final View black) {
        black.animate().alpha(0.0f).setDuration(650L).withEndAction(new Runnable() { // from class: com.cinevault.companion.MainActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m53lambda$showBlackThenHome$33$comcinevaultcompanionMainActivity(black);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$showBlackThenHome$33$com-cinevault-companion-MainActivity, reason: not valid java name */
    /* synthetic */ void m53lambda$showBlackThenHome$33$comcinevaultcompanionMainActivity(View black) {
        this.root.removeView(black);
        enterImmersiveMode();
    }

    /* JADX INFO: Access modifiers changed from: private */
    static class ParticleDissolveView extends View {
        private static final int PARTICLE_COUNT = 140;
        private final PointF[] drift;
        private final PointF[] origins;
        private final Paint paint;
        private float progress;
        private final float[] sizes;

        ParticleDissolveView(Context context) {
            super(context);
            this.paint = new Paint(1);
            this.origins = new PointF[PARTICLE_COUNT];
            this.drift = new PointF[PARTICLE_COUNT];
            this.sizes = new float[PARTICLE_COUNT];
            this.progress = 0.0f;
            this.paint.setStyle(Paint.Style.FILL);
        }

        void start() {
            post(new Runnable() { // from class: com.cinevault.companion.MainActivity$ParticleDissolveView$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    ParticleDissolveView.this.m71x9d62e621();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$start$1$com-cinevault-companion-MainActivity$ParticleDissolveView, reason: not valid java name */
        /* synthetic */ void m71x9d62e621() {
            seedParticles();
            ValueAnimator animator = ValueAnimator.ofFloat(0.0f, 1.0f);
            animator.setDuration(950L);
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.cinevault.companion.MainActivity$ParticleDissolveView$$ExternalSyntheticLambda0
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                    ParticleDissolveView.this.m70x8cad1960(valueAnimator);
                }
            });
            animator.start();
        }

        /* JADX INFO: renamed from: lambda$start$0$com-cinevault-companion-MainActivity$ParticleDissolveView, reason: not valid java name */
        /* synthetic */ void m70x8cad1960(ValueAnimator animation) {
            this.progress = ((Float) animation.getAnimatedValue()).floatValue();
            invalidate();
        }

        private void seedParticles() {
            float w = Math.max(1, getWidth());
            float h = Math.max(1, getHeight());
            for (int i = 0; i < PARTICLE_COUNT; i++) {
                float x = ((float) Math.random()) * w;
                float y = ((float) Math.random()) * h;
                float dx = (((float) Math.random()) - 0.5f) * w * 0.28f;
                float dy = (((float) Math.random()) - 0.5f) * h * 0.22f;
                this.origins[i] = new PointF(x, y);
                this.drift[i] = new PointF(dx, dy);
                this.sizes[i] = (((float) Math.random()) * 8.0f) + 2.0f;
            }
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (this.origins[0] == null) {
                return;
            }
            float fade = 1.0f - this.progress;
            for (int i = 0; i < PARTICLE_COUNT; i++) {
                PointF origin = this.origins[i];
                PointF offset = this.drift[i];
                float x = origin.x + (offset.x * this.progress);
                float y = origin.y + (offset.y * this.progress);
                int alpha = Math.max(0, Math.min(210, (int) (210.0f * fade)));
                int color = i % 3 == 0 ? Color.rgb(198, 255, 0) : -1;
                this.paint.setColor(color);
                this.paint.setAlpha(alpha);
                canvas.drawCircle(x, y, this.sizes[i] * (this.progress + 0.7f), this.paint);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideCustomVideoView() {
        if (this.customVideoView == null) {
            return;
        }
        this.root.removeView(this.customVideoView);
        this.webView.setVisibility(0);
        this.menuButton.setVisibility(0);
        this.castLaunchButton.setVisibility(0);
        this.customVideoView = null;
        if (this.customViewCallback != null) {
            this.customViewCallback.onCustomViewHidden();
            this.customViewCallback = null;
        }
        enterImmersiveMode();
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService("wifi");
            this.multicastLock = wifiManager.createMulticastLock("cinevault-discovery");
            this.multicastLock.setReferenceCounted(false);
            this.multicastLock.acquire();
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(5894);
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        goBack();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.nativeStateHandler.removeCallbacks(this.nativeStatePoll);
        if (this.multicastLock != null && this.multicastLock.isHeld()) {
            this.multicastLock.release();
        }
        if (this.sessionManager != null && this.castSessionListener != null) {
            this.sessionManager.removeSessionManagerListener(this.castSessionListener, Session.class);
        }
        super.onDestroy();
    }
}
