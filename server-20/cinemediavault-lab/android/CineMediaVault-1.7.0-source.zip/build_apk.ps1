$ErrorActionPreference = "Stop"

Set-Location $PSScriptRoot

$studioJava = "C:\Program Files\Android\Android Studio\jbr\bin\java.exe"
if (Test-Path $studioJava) {
    $env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
    $env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
}

$sdkRoot = Join-Path $env:LOCALAPPDATA "Android\Sdk"
if (Test-Path $sdkRoot) {
    $env:ANDROID_HOME = $sdkRoot
    $env:ANDROID_SDK_ROOT = $sdkRoot
    $env:PATH = "$sdkRoot\platform-tools;$env:PATH"
}

if (Test-Path ".\gradlew.bat") {
    .\gradlew.bat assembleDebug
} elseif (Get-Command gradle -ErrorAction SilentlyContinue) {
    gradle assembleDebug
} else {
    $gradleVersion = "8.10.2"
    $toolsDir = Join-Path $env:LOCALAPPDATA "CineVault\tools"
    $gradleHome = Join-Path $toolsDir "gradle-$gradleVersion"
    $gradleBat = Join-Path $gradleHome "bin\gradle.bat"
    if (!(Test-Path $gradleBat)) {
        New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null
        $zipPath = Join-Path $toolsDir "gradle-$gradleVersion-bin.zip"
        Write-Host "Downloading Gradle $gradleVersion..."
        Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip" -OutFile $zipPath
        Expand-Archive -Path $zipPath -DestinationPath $toolsDir -Force
    }
    & $gradleBat assembleDebug
}

Get-ChildItem -Recurse .\app\build\outputs\apk -Filter *.apk | Select-Object FullName,Length
